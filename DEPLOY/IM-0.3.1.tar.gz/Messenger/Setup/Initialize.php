<?php
class Messenger_Setup_Initialize extends Setup_Initialize{}