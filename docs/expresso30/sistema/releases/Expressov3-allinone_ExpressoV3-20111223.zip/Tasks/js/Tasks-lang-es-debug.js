/********************** tine translations of Tasks**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Tasks'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Tasks\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: \nLast-Translator: \nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nPlural-Forms: nplurals=2; plural=n != 1;\nX-Poedit-Language: Spanish\nX-Poedit-Country: NOT SPECIFIED / ANY\nX-Poedit-SourceCharset: utf-8\n"

, "Notification for Task "
: "Notificación por Tarea"

, "manage shared task lists"
: "administrar lista de tareas compartidas"

, "Create new shared tasks lists"
: "Crear nueva lista de tareas compartidas"

, "manage shared tasks favorites"
: ""

, "Create or update shared tasks favorites"
: ""

, "Do you really want to delete the selected task?, Do you really want to delete the selected tasks?"
: [
  "¿Realmente desea borrar la tarea seleccionada?"
 ,"¿Realmente desea borrar las tareas seleccionadas?"

]
, "Tags"
: "Etiquetas"

, "Lead"
: ""

, "Summary"
: "Resumen"

, "Add a task..."
: "Agregar una tarea..."

, "Due Date"
: "Fecha Apta"

, "Priority"
: "Prioridad"

, "Percent"
: "Porcentaje"

, "Status"
: "Estado"

, "Creation Time"
: "Fecha de Creación"

, "Completed"
: "Completado"

, "Responsible"
: "Responsable"

, "Show closed"
: "Visualización Cerrada"

, "You have to supply a due date, because an alarm ist set!"
: ""

, "Due date"
: "Fecha apta"

, "Add Responsible ..."
: "Agregar Responsable..."

, "Notes"
: "Notas"

, "Enter description..."
: "Escribir descripción..."

, "Percentage"
: "Porcentaje"

, "New Task"
: ""

, "Task, Tasks"
: [
  "Tarea"
 ,"Tareas"

]
, "Tasks"
: "Tareas"

, "to do list, to do lists"
: [
  "lista para hacer"
 ,"listas para hacer"

]
, "to do lists"
: "listas para hacer"

, "Quick search"
: "Búsqueda Rápida"

, "Last modified"
: ""

, "Last modifier"
: ""

, "Creator"
: ""

, "All tasks of my taskslists"
: ""

, "My open tasks"
: ""

, "My open tasks this week"
: ""

, "All tasks for me"
: ""

, "All tasks that I am responsible for"
: ""

, "Last modified by me"
: ""

, "All tasks that I have last modified"
: ""

, "Tasks without responsible"
: ""

, "NEEDS-ACTION"
: "NECESITAN-ATENCION"

, "COMPLETED"
: "COMPLETADO"

, "IN-PROCESS"
: "EN-PROCESO"

, "CANCELLED"
: "CANCELADO"

, "%s's personal tasks"
: "Tareas personales de %s"

, "Due"
: "Apta"

, "Organizer"
: "Organizador"

, "Description"
: "Descripción"

, "Telephone"
: ""

, "Email"
: ""

, "All my tasks"
: ""

, "Default Favorite"
: ""

, "The default favorite which is loaded on Tasks startup"
: ""

, "Default Task List"
: ""

, "The default task list to create new tasks in."
: ""



})); 
