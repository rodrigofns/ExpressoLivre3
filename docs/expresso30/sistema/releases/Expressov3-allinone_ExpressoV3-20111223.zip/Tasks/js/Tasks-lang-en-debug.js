/********************** tine translations of Tasks**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Tasks'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Tasks\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2008-07-29 21:14+0100\nLast-Translator: Cornelius Weiss <c.weiss@metaways.de>\nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: en\nX-Poedit-Country: GB\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "Notification for Task "
: "Notification for Task "

, "manage shared task lists"
: "manage shared task lists"

, "Create new shared tasks lists"
: "Create new shared tasks lists"

, "manage shared tasks favorites"
: "manage shared tasks favorites"

, "Create or update shared tasks favorites"
: "Create or update shared tasks favorites"

, "Do you really want to delete the selected task?, Do you really want to delete the selected tasks?"
: [
  "Do you really want to delete the selected task?"
 ,"Do you really want to delete the selected tasks?"

]
, "Tags"
: "Tags"

, "Lead"
: "Lead"

, "Summary"
: "Summary"

, "Add a task..."
: "Add a task..."

, "Due Date"
: "Due Date"

, "Priority"
: "Priority"

, "Percent"
: "Percent"

, "Status"
: "Status"

, "Creation Time"
: "Creation Time"

, "Completed"
: "Completed"

, "Responsible"
: "Responsible"

, "Show closed"
: "Show closed"

, "You have to supply a due date, because an alarm ist set!"
: "You have to supply a due date, because an alarm ist set!"

, "Due date"
: "Due date"

, "Add Responsible ..."
: "Add Responsible ..."

, "Notes"
: "Notes"

, "Enter description..."
: "Enter description..."

, "Percentage"
: "Percentage"

, "New Task"
: "New Task"

, "Task, Tasks"
: [
  "Task"
 ,"Tasks"

]
, "Tasks"
: "Tasks"

, "to do list, to do lists"
: [
  "to do list"
 ,"to do lists"

]
, "to do lists"
: "to do lists"

, "Quick search"
: "Quick search"

, "Last modified"
: "Last modified"

, "Last modifier"
: "Last modifier"

, "Creator"
: "Creator"

, "All tasks of my taskslists"
: "All tasks of my taskslists"

, "My open tasks"
: "My open tasks"

, "My open tasks this week"
: "My open tasks this week"

, "All tasks for me"
: "All tasks for me"

, "All tasks that I am responsible for"
: "All tasks that I am responsible for"

, "Last modified by me"
: "Last modified by me"

, "All tasks that I have last modified"
: "All tasks that I have last modified"

, "Tasks without responsible"
: "Tasks without responsible"

, "NEEDS-ACTION"
: "NEEDS-ACTION"

, "COMPLETED"
: "COMPLETED"

, "IN-PROCESS"
: "IN-PROCESS"

, "CANCELLED"
: "CANCELLED"

, "%s's personal tasks"
: "%s's personal tasks"

, "Due"
: "Due"

, "Organizer"
: "Organizer"

, "Description"
: "Description"

, "Telephone"
: "Telephone"

, "Email"
: "Email"

, "All my tasks"
: "All my tasks"

, "Default Favorite"
: "Default Favorite"

, "The default favorite which is loaded on Tasks startup"
: "The default favorite which is loaded on Tasks startup"

, "Default Task List"
: "Default Task List"

, "The default task list to create new tasks in."
: "The default task list to create new tasks in."

})); 
