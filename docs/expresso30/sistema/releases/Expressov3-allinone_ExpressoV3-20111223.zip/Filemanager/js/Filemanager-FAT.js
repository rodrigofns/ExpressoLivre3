/*
 * Tine 2.0 - Filemanager 
 * Copyright (c) 2007-2011 Metaways Infosystems GmbH (http://www.metaways.de)
 * http://www.gnu.org/licenses/agpl.html AGPL Version 3
 */
Ext.ns("Tine.Filemanager");Tine.Filemanager.Application=Ext.extend(Tine.Tinebase.Application,{hasMainScreen:false,getTitle:function(){return this.i18n.gettext("Filemanager")}});