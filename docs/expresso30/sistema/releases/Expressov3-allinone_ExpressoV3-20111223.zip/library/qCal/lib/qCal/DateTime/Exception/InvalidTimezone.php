<?php
/**
 * Invalid Timezone Exception - thrown when an invalid timezone is attempted
 * @package qCal
 * @subpackage qCal_DateTime
 * @copyright Luke Visinoni (luke.visinoni@gmail.com)
 * @author Luke Visinoni (luke.visinoni@gmail.com)
 * @license GNU Lesser General Public License
 */
class qCal_DateTime_Exception_InvalidTimezone extends qCal_DateTime_Exception {}