/********************** tine translations of Admin**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Admin'] = new Locale.Gettext.PO(({
""
: "Plural-Forms: nplurals=2; plural=n != 1;\nProject-Id-Version: \nPOT-Creation-Date: \nPO-Revision-Date: 2011-12-01 16:28-0300\nLast-Translator: Antonio Carlos da Silva <antonio-carlos.silva@serpro.gov.br>\nLanguage-Team: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: pt_BR\nX-Poedit-Country: BRAZIL\nX-Poedit-SourceCharset: utf-8\n"

, "Your container has been changed"
: "Seu contêiner foi alterado"

, "Your container has been changed by %1$s %2$sNote: %3$s"
: "Seu contêiner foi alterado por %1$s..."

, "manage access log"
: "Administrar log de acesso"

, "delete access log entries"
: "excluir entradas da log de acesso"

, "manage accounts"
: "administrar contas"

, "add and edit users and groups, add group members, change user passwords"
: "adicionar e editar usuários e grupos. adicionar membros a grupos, adcionar direitos sbre aplicações aos pepéis"

, "manage applications"
: "administrar aplicações"

, "enable and disable applications, edit application settings"
: "habilitar e desabilitar aplicações, editar definições de aplicações"

, "manage roles"
: "administrar papéis"

, "add and edit roles, add new members to roles, add application rights to roles"
: "adicionar e editar papéis, adicionar novos membros para papéis, adicionar direitos sobre aplicações a papéis"

, "manage shared tags"
: "administrar etiquetas compartilhados"

, "add, delete and edit shared tags"
: "adicionar, excluir e editar etiquetas compartilhados"

, "manage computers"
: "administrar computadores"

, "add, delete and edit (samba) computers"
: "adicionar, excluir e editar (samba) computadores"

, "manage containers"
: "administrar contêineres"

, "add, delete and edit containers and manage container grants"
: "adicionar,excluir e editar contêineres e administrar privilégios nos contêiners"

, "view access log"
: "visualizar log de acesso"

, "view access log list"
: "visualizar a lista de log de acesso"

, "view accounts"
: "visualizar contas"

, "view accounts list and details"
: "visualizar lista dos detalhes das contas"

, "view applications"
: "visualizar aplicações"

, "view applications list and details"
: "visualizar lista dods detalhes das aplicações"

, "view roles"
: "visualizar papéis"

, "view roles list and details"
: "visualizar lista de detalhes dos papéis"

, "view computers"
: "visualizar computadores"

, "view computers list and details"
: "visualizar lista de detalhes de computadores"

, "view containers"
: "visualizar contêineres"

, "view personal and shared containers"
: "visualizar cotêineres pessoal e compartilhado"

, "Computer Name"
: "Nome do Computador"

, "Description"
: "Descrição"

, "ID"
: "ID"

, "Name"
: "Nome"

, "Container, Containers"
: [
  "Contêiner"
 ,"Contêineres"

]
, "Container Name"
: "Nome do Computador"

, "Application, Applications"
: [
  "Aplicação"
 ,"Aplicações"

]
, "Type"
: "Tipo"

, "personal"
: "pessoal"

, "shared"
: "compartilhado"

, "Color"
: "Cor"

, "Note for Owner"
: "Nota do Proprietário"

, "Confirm"
: "Confirma"

, "Do you really want to delete the selected groups?"
: "Você tem certeza que quer excluir os grupos selecionados?"

, "Deleting group(s)..."
: "Deletando grup(s)..."

, "Failed"
: "Falhou"

, "Some error occurred while trying to delete the group."
: "Alguns erros ocorreram quando tentava excluir o grupo."

, "add group"
: "adicionar grupo"

, "edit group"
: "editar grupo"

, "delete group"
: "excluir grupo"

, "Search:"
: "Pesquisar:"

, "Displaying groups {0} - {1} of {2}"
: "Exibindo grupos {0} - {1} de {2}"

, "No groups to display"
: "Nenhum grupo para exibir"

, "Computer, Computers"
: [
  "Computador"
 ,"Computadores"

]
, "Please wait"
: "Aguarde"

, "Updating Memberships"
: "Atualizando Participantes"

, "Could not save role."
: "Não pode salvar o papel."

, "Errors"
: "Erros"

, "Please fix the errors noted."
: "Por favor, corrija os erros."

, "Deleting role..."
: "Deletando papel..."

, "Some error occurred while trying to delete the role."
: "Alguns erros ocorreram enquanto tentava excluir o papel."

, "Rights"
: "Direitos"

, "Members"
: "Membros"

, "Role Name"
: "Nome do Papel"

, "Transferring {0}..."
: "Transferindo {0}..."

, "Role"
: "Papel"

, "Add New Role"
: "Adicionar Novo Papel"

, "Edit Role \"{0}\""
: "Editar Papel \"{0}\""

, "enable account"
: "Habilitar conta"

, "disable account"
: "desabilitar conta"

, "reset password"
: "redefinir senha"

, "User"
: "Usuário"

, "Users"
: "Usuários"

, "Status"
: "Estado"

, "Displayname"
: "Nome de exibição"

, "Loginname"
: "Nome de login"

, "Last name"
: "Último nome"

, "First name"
: "Primeiro nome"

, "Email"
: "Email"

, "OpenID"
: "OpenID"

, "Last login at"
: "Último login às"

, "Last login from"
: "Último login de"

, "Password changed"
: "Senha alterada"

, "Expires"
: "Expira em"

, "Set new password"
: "Definir nova senha"

, "Please enter the new password:"
: "Por favor entre uma nova senha"

, "Samba User, Samba Users"
: [
  "Usuário Samba"
 ,"Usuários Samba"

]
, "Email User, Email Users"
: [
  "Email do usuario"
 ,"Email dos usuários"

]
, "Domain is not allowed. Check your SMTP domain configuration."
: "Domínio não permitido. Verifique a configuração de domínio do seu SMTP."

, "Passwords do not match!"
: "Senhas não são idênticas!"

, "Passwords match!"
: "Senhas idênticas!"

, "Primary group"
: "Grupo primário"

, "Unix"
: "Unix"

, "Home Directory"
: "Diretório do usuário"

, "Login Shell"
: ""

, "Windows"
: ""

, "Home Drive"
: "Drive do usuário"

, "Logon Time"
: "Hora do logon"

, "never logged in"
: "Nunca logou"

, "Home Path"
: ""

, "Logoff Time"
: "Hora do logoff"

, "never logged off"
: "Nunca fez logoff"

, "Profile Path"
: ""

, "Password Last Set"
: "Última definição de senha"

, "never"
: "nunca"

, "Logon Script"
: ""

, "Password Can Change"
: "Pode alterar a senha"

, "not set"
: "não definido"

, "Password Must Change"
: "A senha deve ser alterada"

, "Kick Off Time"
: ""

, "IMAP Quota (MB)"
: "Cota IMAP (MB)"

, "Quota"
: "Cota"

, "no quota set"
: "Sem cota definida"

, "Current Mailbox size"
: "Tamanho da caixa de mensagens"

, "Sieve Quota (MB)"
: "COta Sieve (MB)"

, "Current Sieve size"
: "Tamanho do Sieve"

, "Information"
: "iInformação"

, "Last Login"
: "Último login"

, "Email Alias"
: "Email alternativo"

, "Add an alias address..."
: "Adicionar um endereço alternativo..."

, "Email Forward"
: "Email de encaminhamento"

, "Add a forward address..."
: "Adicionar um endereço de encaminhamento"

, "Forward Only"
: "Sómente Encaminhar"

, "Password confirmation"
: "Confirmação da senha"

, "Repeat password"
: "Repita a senha"

, "Cancel"
: "Cancelar"

, "Ok"
: "OK"

, "Account"
: "Conta"

, "First Name"
: "Primeiro Nome"

, "Last Name"
: "Último Nome"

, "Login Name"
: "Nome de login"

, "Password"
: "Senha"

, "no password set"
: "Senha não definida"

, "Emailaddress"
: "Endereço de Email"

, "enabled"
: "habilitado"

, "disabled"
: "desabilitado"

, "expired"
: "expirado"

, "blocked"
: "bloqueado"

, "Visibility"
: "Visibilidade"

, "Display in addressbook"
: "Exibir no catalogo de endereços"

, "Hide from addressbook"
: "Não exibir no catalogo de endereços"

, "Saved in Addressbook"
: "Salva no catalogo de endereços"

, "don't know"
: "Não conhecido"

, "Password set"
: "Senha definida"

, "User groups"
: "Grupo de usuários"

, "User roles"
: "Papéis dos usuários"

, "Fileserver"
: "Servidor de arquivos"

, "IMAP"
: "IMAP"

, "SMTP"
: "SMPT"

, "Groups"
: "Grupos"

, "Roles"
: "Papéis"

, "Computers"
: "Computadores"

, "Applications"
: "Aplicações"

, "Access Log"
: "Log de acesso"

, "Shared Tags"
: "Etiquetas Compartilhadas"

, "Containers"
: "Contêineres"

, "Admin"
: "Admin"

, "{0} Settings"
: "{0} Definições"

, "enable application"
: "habilitar aplicação"

, "disable application"
: "desabilitar aplicação"

, "settings"
: "definições"

, "unknown status ({0})"
: "estado desconhecido ({0})"

, "Displaying application {0} - {1} of {2}"
: "Exibindo aplicação {0} - {1} de {2}"

, "No applications to display"
: "Nenhuma aplicação para exibir"

, "Order"
: "Ordem"

, "Version"
: "Versão"

, "Default Addressbook for new contacts and groups"
: "Catalogo de endereços default para novos contatos e grupos"

, "Could not save group."
: "Não pode salvar o grupo."

, "Group Members"
: "Membros do Grupo"

, "Group Name"
: "Nome do Grupo"

, "Group, Groups"
: [
  "Grupo"
 ,"Grupos"

]
, "Add new group"
: "adicionar novo grupo"

, "Edit Group \"{0}\""
: "Editar Grupo \"{0}\""

, "Updating Tag"
: "Atualizando etiqueta"

, "Could not save tag."
: "Não pode salvar etiqueta."

, "Allowed Contexts"
: "Contextos permitidos"

, "Context"
: "Contexto"

, "Account Rights"
: "Direitos da conta"

, "View"
: "Visualizar"

, "Use"
: "Usar"

, "Tag Name"
: "Nome da Etiqueta"

, "Tag"
: "Etiqueta"

, "Add New Tag"
: "Adicionar nova Etiqueta"

, "Edit Tag \"{0}\""
: "Editar Etiqueta \"{0}\""

, "Do you really want to delete the selected roles?"
: "Você deseja excluir os papéis selecionados?"

, "Deleting role(s)..."
: "Deletando papél(is)..."

, "add role"
: "adicionar papel"

, "edit role"
: "editar papel"

, "delete role"
: "excluir papel"

, "Displaying roles {0} - {1} of {2}"
: "Exibindo papéis {0} - {1} de {2}"

, "No roles to display"
: "Nenhum papél para exibir"

, "Do you really want to delete the selected tags?"
: "Você deseja excluir os etiquetas selecionados?"

, "Deleting tag(s)..."
: "Deletando etiqueta(s)..."

, "add tag"
: "adicionar etiqueta"

, "edit tag"
: "editar etiqueta"

, "delete tag"
: "excluir etiqueta"

, "Displaying tags {0} - {1} of {2}"
: "Exibindo etiquetas {0} - {1} de {2}"

, "No tags to display"
: "Nenhuma etiqueta para exibir"

, "IP Address"
: "Endereço IP"

, "Login Time"
: "Hora de login"

, "Logout Time"
: "Hora do logout"

, "Client Type"
: "Tipo de Cliente"

, "Session ID"
: "ID da sessão"

, "Result"
: "Resultado"

, "user blocked"
: "usuário bloqueado"

, "password expired"
: "senha expirada"

, "user disabled"
: "usuario desabilitado"

, "invalid password"
: "senha inválida"

, "ambiguous username"
: "usuário desconhecido"

, "user not found"
: "Usuário não localizado"

, "failure"
: "falha"

, "success"
: "sucesso"


})); 
