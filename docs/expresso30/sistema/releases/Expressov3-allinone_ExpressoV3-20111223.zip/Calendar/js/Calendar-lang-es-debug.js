/********************** tine translations of Calendar**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Calendar'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Calendar\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: \nLast-Translator: \nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nPlural-Forms: nplurals=2; plural=n != 1;\nX-Poedit-Language: Spanish\nX-Poedit-Country: NOT SPECIFIED / ANY\nX-Poedit-SourceCharset: utf-8\n"

, "Alarm for event \"%1$s\" at %2$s"
: "Alarma para evento \"%1$s\" a las %2$s"

, "Event invitation \"%1$s\" at %2$s"
: "Invitación a Evento \"%1$s\" a las %2$s"

, "Event \"%1$s\" at %2$s has been canceled"
: ""

, "Event \"%1$s\" at %2$s has been rescheduled"
: "Evento \"%1$s\" a las %2$s ha sido reagendado"

, "Event \"%1$s\" at %2$s has been updated"
: "Evento \"%1$s\" a las %2$s ha sido actualizado"

, "%1$s accepted event \"%2$s\" at %3$s"
: "%1$s aceptó el evento \"%2$s\" a las %3$s"

, "%1$s declined event \"%2$s\" at %3$s"
: "%1$ rechazó el evento \"%2$s\" a las %3$s"

, "Tentative response from %1$s for event \"%2$s\" at %3$s"
: "Respuesta tentativa de %1$s para el evento \"%2$s\" a las %3$s"

, "No response from %1$s for event \"%2$s\" at %3$s"
: "No hay respuesta de %1$s para el evento \"%2$s\" a las %3$s"

, "Attendee changes for event \"%1$s\" at %2$s"
: "Cambios de Asistentes para el evento \"%1$s\" a las %2$s"

, "manage shared calendars"
: "manejar calendarios compartidos"

, "Create new shared calendars"
: "Crear nuevos calendarios compartidos"

, "manage shared calendars favorites"
: ""

, "Create or update shared calendars favorites"
: ""

, "manage resources"
: "manejar recursos"

, "All Rights to administrate resources"
: "Todos los Permisos para administrar recursos"

, "private classification"
: ""

, "recurring event"
: ""

, "has alarm"
: ""

, "Loading events, please wait..."
: "Cargando eventos, por favor espere..."

, "Scheduling Conflict"
: "Conflicto de Planificación"

, "The following attendee are busy at the requested time:"
: "El siguiente asistente se encuentra ocupado para la fecha solicitada:"

, "Ignore Conflict"
: "Ignorar Conflicto"

, "Edit Event"
: "Editar Evento"

, "Cancel this action"
: ""

, "Update Event"
: "Actualizar Evento"

, "Update this event only"
: "Actualizar este evento solamente"

, "Update this and all future events"
: ""

, "Update whole series"
: "Actualizar toda la serie"

, "Update nothing"
: "No actualizar"

, "New Event"
: "Evento Nuevo"

, "{0}, the {1}. of {2}"
: "{0}, {1} de {2}"

, "Week"
: "Semana"

, "Name"
: "Nombre"

, "Email"
: "Email"

, "Location"
: "Ubicación"

, "Print Page"
: ""

, "Day"
: "Día"

, "Month"
: "Mes"

, "Set my response"
: ""

, "Please Change Selection"
: "Por favor Cambie la Selección"

, "Your selection contains recurring events. Recuring events must be deleted seperatly!"
: "Los elementos seleccionados contienen eventos repetitivos. ¡Los eventos repetitivos deben eliminarse por separado!"

, "Delete Event"
: "Eliminar Evento"

, "Delete this event only"
: "Eliminar sólo este evento"

, "Delete this and all future events"
: "Eliminar éste y todos los eventos futuros"

, "Delete whole series"
: "Eliminar toda la serie"

, "Delete nothing"
: "No Eliminar"

, "Do you really want to delete this event?, Do you really want to delete the {0} selected events?"
: [
  "¿Realmente desea eliminar este evento?"
 ,"¿Realmente desea eliminar los {0} eventos seleccioniados?"

]
, "Could not Print"
: ""

, "Sorry, your current view does not support printing."
: ""

, "Calendar, Calendars"
: [
  "Calendario"
 ,"Calendarios"

]
, "Attendee Status"
: ""

, "Is a location"
: "Es una ubicación"

, "Description"
: "Descripción"

, "Enter description..."
: "Ingrese descripción..."

, "Originally"
: "Originalmente"

, "WK"
: "SEM"

, "{0} more..."
: "{0} más..."

, "Unknown calendar"
: "Calendario desconocido"

, "{0} {1} o'clock"
: "{0} {1} en punto"

, "Summary"
: "Resumen"

, "Start Time"
: "Hora de Inicio"

, "End Time"
: "Hora de Término"

, "Blocking"
: "Bloquear"

, "Organizer"
: "Organizador"

, "Attendee"
: "Asistentes"

, "Week {0} :"
: ""

, "whole day"
: "todo el día"

, "Event, Events"
: [
  "Evento"
 ,"Eventos"

]
, "Events"
: "Eventos"

, "Calendars"
: "Calendarios"

, "Quick search"
: ""

, "Attender, Attendee"
: [
  "Asistente"
 ,"Asistentes"

]
, "No Information"
: "Sin Información"

, "No response"
: "No hay respuesta"

, "Accepted"
: "Aceptado"

, "Declined"
: "Rechazado"

, "Tentative"
: "Tentativo"

, "Resource, Resources"
: [
  "Recurso"
 ,"Recursos"

]
, "Resources"
: "Recursos"

, "Manage Resources"
: "Administrar Recursos"

, "Select Attendee"
: ""

, "Recurrances"
: "Repeticiones"

, "No recurring rule defined"
: "No se definió una regla de repetición"

, "None"
: "Ninguno"

, "Daily"
: "Diariamente"

, "Weekly"
: "Semanalmente"

, "Monthly"
: "Mensualmente"

, "Yearly"
: "Anualmente"

, "Exceptions of reccuring events can't have recurrences themselves."
: ""

, "forever"
: "para siempre"

, "Forever"
: "Para Siempre"

, "at"
: "a"

, "Until"
: "Hasta"

, "Until has to be after event start"
: "Debe ocurrir hasta que el evento comience"

, "Every {0}. Day"
: ""

, "Every {0}. Week at"
: ""

, "Every {0}. Month"
: ""

, "at the"
: "en el (la)"

, "first"
: "primero"

, "second"
: "segundo"

, "third"
: "tercero"

, "fourth"
: "cuarto"

, "last"
: "último"

, "Every {0}. Year"
: ""

, "of"
: "de"

, "Mini Calendar"
: ""

, "non-blocking"
: "no bloquear"

, "Private"
: ""

, "Enter description"
: "Ingrese descripción"

, "End date is not valid"
: "La fecha de término no es válida"

, "End date must be after start date"
: "La fecha de término debe ser mayor a la fecha de inicio"

, "Start date is not valid"
: "La fecha de inicio no es válida"

, "Role"
: "Cargo"

, "Quantity"
: "Cantidad"

, "This is the calendar where the attender has saved this event in"
: "Este es el calendario donde el asistente ha guardado este evento en"

, "Type"
: "Tipo"

, "User"
: "Usuario"

, "Group"
: "Grupo"

, "Member of group"
: ""

, "Status"
: "Estado"

, "Remove Attender"
: "Eliminar Asistente"

, "Click here to invite another attender..."
: "Haga clic aquí para invitar a otro asistente..."

, "(as a group member)"
: "(como un miembro del grupo)"

, "Required"
: "Requerido"

, "Optional"
: "Opcional"

, "Updates"
: "Actualizaciones"

, "%1$s changed from \"%2$s\" to \"%3$s\""
: "%1$s cambió a \"%2$s\" to \"%3$s\""

, "%1$s has been invited"
: "%1$s ha sido invitado"

, "%1$s has been removed"
: "%1$s ha sido eliminado"

, "%1$s accepted invitation"
: "%1$s aceptó la invitación"

, "%1$s declined invitation"
: "%1$s rechazó la invitación"

, "Tentative response from %1$s"
: "Respuesta Tentativa de %1$s"

, "No response from %1$s"
: "No hay respuesta de %1$s"

, "Event details"
: "Detalles del Evento"

, "All events I attend"
: ""

, "Awaiting response"
: ""

, "Events I have not yet responded to"
: ""

, "Declined events"
: ""

, "Events I have declined"
: ""

, "I'm organizer"
: ""

, "Events I'm the organizer of"
: ""

, "%s's personal calendar"
: "calendario personal de %s"

, "Start"
: "Comienza"

, "End"
: "Termina"

, "Classification"
: "Clasificación"

, "Priority"
: "Prioridad"

, "Url"
: "Url"

, "Recurrance rule"
: "Regla de Repetición"

, "Is all day event"
: "es un evento de todo el día"

, "Organizer timezone"
: "Zona Horaria del Organizador"

, "Yes"
: "Si"

, "No"
: "No"

, "unknown"
: "desconocido"

, "This contact has been automatically added by the system as an event attender"
: "Este contacto se a agregado automáticamente por el sistema como un asistente al evento"

, "unknown)"
: "desconocido)"

, "All my events"
: ""

, "Position on the left time axis, day and week view should start with"
: ""

, "Default Calendar"
: "Calendario por defecto"

, "The default calendar for invitations and new events"
: "El calendario por defecto de las invitaciones y nuevos eventos"

, "Default Favorite"
: ""

, "The default favorite which is loaded on calendar startup"
: ""

, "Get Notification Emails"
: "Obtener Emails de Notificación"

, "The level of actions you want to be notified about. Please note that organizers will get notifications for all updates including attendee answers unless this preference is set to \"Never\""
: "El nivel de acciones que desea se le notifice. Por favor considere que los organizadores obtendrán las notificaciones de todas actualizaciones acerca de la asistencia de los participantes, a no ser que Ud. lo configure de otra manera en las preferencias \"Nunca\""

, "Send Notifications Emails of own Actions"
: "Enviar Emails de Notificación de las Acciones propias"

, "Get notifications emails for actions you did yourself"
: "Obtener emails de notificación de las acciones que usted hizo"

, "Never"
: ""

, "On invitation and cancellation only"
: ""

, "On time changes"
: ""

, "On all updates but attendee responses"
: ""

, "On attendee responses too"
: ""



















})); 
