/********************** tine translations of Sales**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Sales'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Sales\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2008-07-29 21:14+0100\nLast-Translator: Cornelius Weiss <c.weiss@metaways.de>\nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: en\nX-Poedit-Country: GB\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "manage products"
: "manage products"

, "add, edit and delete products"
: "add, edit and delete products"

, "Title"
: "Title"

, "Description"
: "Description"

, "Enter description..."
: "Enter description..."

, "Quick search"
: "Quick search"

, "Summary"
: "Summary"

, "Contract number"
: "Contract number"

, "Status"
: "Status"

, "Name"
: "Name"

, "Price"
: "Price"

, "Manufacturer"
: "Manufacturer"

, "Category"
: "Category"

, "Tags"
: "Tags"

, "Product, Products"
: [
  "Product"
 ,"Products"

]
, "record list, record lists"
: [
  "record list"
 ,"record lists"

]
, "Product name"
: "Product name"

, "Contract, Contracts"
: [
  "Contract"
 ,"Contracts"

]
, "contracts list, contracts lists"
: [
  "contracts list"
 ,"contracts lists"

]
, "Products"
: "Products"

, "All Products"
: "All Products"

, "Contracts"
: "Contracts"

, "All Contracts"
: "All Contracts"

, "Shared Contracts"
: "Shared Contracts"

})); 
