/********************** tine translations of Sales**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Sales'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Sales\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2010-02-10 16:34-0400\nLast-Translator: \nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: Spanish\nX-Poedit-Country: NOT SPECIFIED / ANY\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "manage products"
: "administrar productos"

, "add, edit and delete products"
: "agregar, editar y borrar productos"

, "Title"
: "Título"

, "Description"
: "Descripción"

, "Enter description..."
: "Escribir Descripción..."

, "Quick search"
: "Búsqueda Rápida"

, "Summary"
: "Resumen"

, "Contract number"
: "Número de Contrato"

, "Status"
: "Estado"

, "Name"
: "Nombre"

, "Price"
: "Precio"

, "Manufacturer"
: "Manufacturero"

, "Category"
: "Categoría"

, "Tags"
: "Etiquetas"

, "Product, Products"
: [
  "Producto"
 ,"Productos"

]
, "record list, record lists"
: [
  "lista de registro"
 ,"lista de registros"

]
, "Product name"
: "Nombre del producto"

, "Contract, Contracts"
: [
  "Contrato"
 ,"Contratos"

]
, "contracts list, contracts lists"
: [
  "listado de contrato"
 ,"listado de contratos"

]
, "Products"
: "Productos"

, "All Products"
: "Todos los Productos"

, "Contracts"
: "Contratos"

, "All Contracts"
: "Todos los Contratos"

, "Shared Contracts"
: "Contratos Compartidos"

})); 
