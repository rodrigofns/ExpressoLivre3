/********************** tine translations of Crm**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Crm'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Crm\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2010-02-10 15:39-0400\nLast-Translator: \nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: Spanish\nX-Poedit-Country: NOT SPECIFIED / ANY\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "State"
: "Estado"

, "Role"
: "Cargo"

, "Source"
: "Fuente"

, "Start"
: "Iniciar"

, "Scheduled end"
: "Final previsto"

, "End"
: "Fin"

, "Turnover"
: "volúmen de ventas"

, "Probability"
: "Probabilidad"

, "Folder"
: "Carpeta"

, "Updated by"
: "Actualizado por"

, "Updated Fields:"
: "Campos Actualizados:"

, "%s changed from %s to %s."
: "%s ha sido cambiado desde %s a %s."

, "Lead %s has been changed"
: "Gestor %s ha sido cambiado"

, "Lead %s has been created"
: ""

, "manage leads"
: "administrar gestores"

, "add, edit and delete leads"
: "agregar, editar y borrar gestores"

, "manage shared lead folders"
: "administrar carpetas compartidas de gestores"

, "Create new shared lead folders"
: "Crear nuevas carpetas compartidas de gestores"

, "manage shared leads favorites"
: ""

, "Create or update shared leads favorites"
: ""

, "Lead Data"
: "Datos de Gestor"

, "Leadstate"
: "Estadodegestión"

, "Leadtype"
: "Tipodegestión"

, "Leadsource"
: "Fuentedegestión"

, "End Scheduled"
: "Final Agendado"

, "Contacts"
: "Contactos"

, "Address"
: "Dirección"

, "Telephone"
: "Teléfono"

, "Email"
: "Email"

, "Tasks"
: "Tareas"

, "Due Date"
: "Fecha de Vencimiento"

, "Priority"
: "Prioridad"

, "Products"
: "Productos"

, "low"
: "bajo"

, "normal"
: "normal"

, "high"
: "alto"

, "urgent"
: "urgente"

, "Add new {0}"
: "Agregar nuevo {0}"

, "Unlink {0}"
: "Desvincular {0}"

, "Unlink selected {0}"
: "Desvincular seleccionado {0}"

, "Edit {0}"
: "Editar {0}"

, "Edit selected {0}"
: "Editar seleccionado {0}"

, "Lead Source, Lead Sources"
: [
  ""
 ,""

]
, "Add a Leadsource..."
: "Agregar una fuente de gestión..."

, "New Lead"
: ""

, "Quick search"
: "Búsqueda Rápida"

, "Lead name"
: "Nombre del gestor"

, "Last modified"
: "Última Modificación"

, "Last modifier"
: ""

, "Creation Time"
: "Fecha de Creación"

, "Creator"
: ""

, "Lead id"
: "Id del gestor"

, "Tags"
: "Etiquetas"

, "Partner"
: "Socio"

, "Customer"
: "Cliente"

, "Probable Turnover"
: ""

, "Export Lead"
: "Expotar Gestion"

, "Export as PDF"
: "Expotar como PDF"

, "Export as CSV"
: "Expotar como PDF"

, "Export as ODS"
: "Exportar como ODS"

, "Export as XLS"
: "Exportar como XLS"

, "Show closed"
: "Función cerrada"

, "Phone"
: "Teléfono"

, "Mobile"
: "Celular"

, "Fax"
: "Fax"

, "E-Mail"
: "E-Mail"

, "Web"
: "Página Web"

, "Leadstates"
: "Estadosdegestión"

, "Leadsources"
: "Fuentesdegestión"

, "Leadtypes"
: "Tiposdegestión"

, "Status"
: "Estado"

, "Estimated end"
: "Final estimado"

, "Contact"
: "Contacto"

, "CRM Role"
: "Cargo CRM"

, "No Tasks to display"
: "No hay tareas para mostrar"

, "Summary"
: "Resumen"

, "Add a task..."
: "Agregar una tarea..."

, "Percent"
: "Porcentaje"

, "Lead Type, Lead Types"
: [
  ""
 ,""

]
, "Add a Leadtype..."
: "Agregar un tipo de gestión..."

, "Lead, Leads"
: [
  "Gestor"
 ,"Gestores"

]
, "lead list, lead lists"
: [
  ""
 ,""

]
, "lead lists"
: ""

, "Settings, Settings"
: [
  "Preferencias"
 ,""

]
, "record list, record lists"
: [
  "lista de registro"
 ,"lista de registros"

]
, "Defaults"
: "Predeterminados"

, "You do not have the run right for the Tasks application or it is not activated."
: ""

, "You do not have the run right for the Sales application or it is not activated."
: ""

, "Enter short name"
: "Escribir Nombre Abreviado"

, "Expected turnover"
: "Volúmen de ventas esperado"

, "Description"
: "Descripción"

, "Enter description"
: "Escribir descripción"

, "Lead State, Lead States"
: [
  ""
 ,""

]
, "Add a Leadstate..."
: "Agregar un estado de gestión..."

, "Change type to Customer"
: "Cambiar tipo a Cliente"

, "Responsible"
: "Responsable"

, "Change type to Responsible"
: "Cambiar tipo a Responsable"

, "Change type to Partner"
: "Cambiar tipo a Socio"

, "Change contact type"
: "Cambiar tipo de contacto"

, "Search for Contacts to add ..."
: "Buscar Contactos para agregar ..."

, "Name"
: "Nombre"

, "Data"
: "Datos"

, "Cellphone"
: "Teléfono Celular"

, "Product"
: "Producto"

, "Price"
: "Precio"

, "Quantity"
: "Cantidad"

, "Search for Products to add ..."
: "Buscar Productos para agregar ..."

, "All leads I have read grants for"
: ""

, "Last modified by me"
: ""

, "All leads that I have last modified"
: ""

, "My leads"
: ""

, "All leads that I am responsible for"
: ""

, "Leads with overdue tasks"
: ""

, "%s's personal leads"
: "gestores personales de %s"

, "Reseller"
: "Revendedor"

, "open"
: "abrir"

, "contacted"
: "contactado"

, "waiting for feedback"
: "esperando reacción"

, "quote sent"
: "presupuesto enviado"

, "accepted"
: "aceptado"

, "lost"
: "perdido"

, "Market"
: "Mercado"

, "Website"
: "Sitio Web"

, "All leads"
: ""

, "Get Notification Emails"
: ""

, "The level of actions you want to be notified about."
: ""

, "Send Notifications Emails for own actions"
: ""

, "Get notifications emails for actions you did yourself"
: ""

, "Default Favorite"
: ""

, "The default favorite which is loaded on crm startup"
: ""















})); 
