<?php
/**
 * qCal_DateTime is a sub-package of qCal, so it has its own exceptions.
 * 
 * @package qCal
 * @subpackage qCal_DateTime
 * @copyright Luke Visinoni (luke.visinoni@gmail.com)
 * @author Luke Visinoni (luke.visinoni@gmail.com)
 * @license GNU Lesser General Public License
 */
class qCal_DateTime_Exception extends qCal_Exception {}