/********************** tine translations of Timetracker**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Timetracker'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Timetracker\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2008-07-29 21:14+0100\nLast-Translator: Cornelius Weiss <c.weiss@metaways.de>\nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: en\nX-Poedit-Country: GB\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "Manage timeaccounts"
: "Manage timeaccounts"

, "Add, edit and delete timeaccounts (includes all timesheet grants)"
: "Add, edit and delete timeaccounts (includes all timesheet grants)"

, "Add timeaccounts"
: "Add timeaccounts"

, "Manage shared timetracker favorites"
: "Manage shared timetracker favorites"

, "Create or update shared timetracker favorites"
: "Create or update shared timetracker favorites"

, "Update {0} records"
: "Update {0} records"

, "Cancel"
: "Cancel"

, "Ok"
: "Ok"

, "Success"
: "Success"

, "Updated {0} records"
: "Updated {0} records"

, "Quick search"
: "Quick search"

, "Account"
: "Account"

, "Date"
: "Date"

, "Description"
: "Description"

, "Billable"
: "Billable"

, "Cleared"
: "Cleared"

, "Tags"
: "Tags"

, "Start time"
: "Start time"

, "Time Account, Time Accounts"
: [
  "Time Account"
 ,"Time Accounts"

]
, "Time Account closed"
: "Time Account closed"

, "Cleared in"
: "Cleared in"

, "Duration"
: "Duration"

, "timeframe"
: "timeframe"

, "summary"
: "summary"

, "Total Timesheets"
: "Total Timesheets"

, "Billable Timesheets"
: "Billable Timesheets"

, "Total Time"
: "Total Time"

, "Time of Billable Timesheets"
: "Time of Billable Timesheets"

, "Detail"
: "Detail"

, "Export Timesheets"
: "Export Timesheets"

, "Export as ODS"
: "Export as ODS"

, "Export as CSV"
: "Export as CSV"

, "Export as ..."
: "Export as ..."

, "Mass Update"
: "Mass Update"

, "Update field:"
: "Update field:"

, "Not a valid time"
: "Not a valid time"

, "Billed in ..."
: "Billed in ..."

, "Timesheet, Timesheets"
: [
  "Timesheet"
 ,"Timesheets"

]
, "Select Time Account..."
: "Select Time Account..."

, "Searching..."
: "Searching..."

, "Start"
: "Start"

, "not set"
: "not set"

, "Enter description..."
: "Enter description..."

, "not cleared yet..."
: "not cleared yet..."

, "Cleared In"
: "Cleared In"

, "Failed"
: "Failed"

, "Could not save {0}."
: "Could not save {0}."

, "Booking deadline for this Timeaccount has been exceeded."
: "Booking deadline for this Timeaccount has been exceeded."

, "{0}"
: "{0}"

, "Number"
: "Number"

, "Title"
: "Title"

, "Unit"
: "Unit"

, "Unit Price"
: "Unit Price"

, "Budget"
: "Budget"

, "Status"
: "Status"

, "closed"
: "closed"

, "open"
: "open"

, "Billed"
: "Billed"

, "not yet billed"
: "not yet billed"

, "to bill"
: "to bill"

, "billed"
: "billed"

, "Booking deadline"
: "Booking deadline"

, "none"
: "none"

, "last week"
: "last week"

, "Timesheets are billable"
: "Timesheets are billable"

, "Enter description"
: "Enter description"

, "Access"
: "Access"

, "Book Own"
: "Book Own"

, "The grant to add Timesheets to this Timeaccount"
: "The grant to add Timesheets to this Timeaccount"

, "View All"
: "View All"

, "The grant to view Timesheets of other users"
: "The grant to view Timesheets of other users"

, "Book All"
: "Book All"

, "The grant to add Timesheets for other users"
: "The grant to add Timesheets for other users"

, "Manage Clearing"
: "Manage Clearing"

, "The grant to manage clearing of Timesheets"
: "The grant to manage clearing of Timesheets"

, "Export"
: "Export"

, "The grant to export Timesheets of Timeaccount"
: "The grant to export Timesheets of Timeaccount"

, "Manage All"
: "Manage All"

, "Includes all other grants"
: "Includes all other grants"

, "Permissions"
: "Permissions"

, "New Timesheet"
: "New Timesheet"

, "Timesheets"
: "Timesheets"

, "All Timesheets"
: "All Timesheets"

, "Timeaccounts"
: "Timeaccounts"

, "All Timeaccounts"
: "All Timeaccounts"

, "Time Account - Status"
: "Time Account - Status"

, "Show closed"
: "Show closed"

, "timesheets list, timesheets lists"
: [
  "timesheets list"
 ,"timesheets lists"

]
, "timeaccount list, timeaccount lists"
: [
  "timeaccount list"
 ,"timeaccount lists"

]
, "Created By"
: "Created By"

, "Timesheets today"
: "Timesheets today"

, "Timesheets this week"
: "Timesheets this week"

, "Timesheets last week"
: "Timesheets last week"

, "Timesheets this month"
: "Timesheets this month"

, "Timesheets last month"
: "Timesheets last month"

, "Timetracker"
: "Timetracker"

, "Timesheets ODS export configuration"
: "Timesheets ODS export configuration"

, "Use this configuration for the timesheet ODS export."
: "Use this configuration for the timesheet ODS export."

, "default"
: "default"

})); 
