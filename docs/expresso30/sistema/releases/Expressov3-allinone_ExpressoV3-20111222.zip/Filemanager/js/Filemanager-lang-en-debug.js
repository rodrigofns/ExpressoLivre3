/********************** tine translations of Filemanager**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Filemanager'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Filemanager\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2008-07-29 21:14+0100\nLast-Translator: Cornelius Weiss <c.weiss@metaways.de>\nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: en\nX-Poedit-Country: GB\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "manage shared folders"
: "manage shared folders"

, "Create new shared folders"
: "Create new shared folders"

, "Filemanager"
: "Filemanager"

, "%s's personal files"
: "%s's personal files"

})); 
