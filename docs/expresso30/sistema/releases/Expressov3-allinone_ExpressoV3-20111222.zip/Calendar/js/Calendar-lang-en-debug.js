/********************** tine translations of Calendar**********************/ 
Locale.Gettext.prototype._msgs['./LC_MESSAGES/Calendar'] = new Locale.Gettext.PO(({
""
: "Project-Id-Version: Tine 2.0 - Calendar\nPOT-Creation-Date: 2008-05-17 22:12+0100\nPO-Revision-Date: 2008-07-29 21:14+0100\nLast-Translator: Cornelius Weiss <c.weiss@metaways.de>\nLanguage-Team: Tine 2.0 Translators\nLanguage: \nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Poedit-Language: en\nX-Poedit-Country: GB\nX-Poedit-SourceCharset: utf-8\nPlural-Forms: nplurals=2; plural=n != 1;\n"

, "Alarm for event \"%1$s\" at %2$s"
: "Alarm for event \"%1$s\" at %2$s"

, "Event invitation \"%1$s\" at %2$s"
: "Event invitation \"%1$s\" at %2$s"

, "Event \"%1$s\" at %2$s has been canceled"
: "Event \"%1$s\" at %2$s has been canceled"

, "Event \"%1$s\" at %2$s has been rescheduled"
: "Event \"%1$s\" at %2$s has been rescheduled"

, "Event \"%1$s\" at %2$s has been updated"
: "Event \"%1$s\" at %2$s has been updated"

, "%1$s accepted event \"%2$s\" at %3$s"
: "%1$s accepted event \"%2$s\" at %3$s"

, "%1$s declined event \"%2$s\" at %3$s"
: "%1$s declined event \"%2$s\" at %3$s"

, "Tentative response from %1$s for event \"%2$s\" at %3$s"
: "Tentative response from %1$s for event \"%2$s\" at %3$s"

, "No response from %1$s for event \"%2$s\" at %3$s"
: "No response from %1$s for event \"%2$s\" at %3$s"

, "Attendee changes for event \"%1$s\" at %2$s"
: "Attendee changes for event \"%1$s\" at %2$s"

, "manage shared calendars"
: "manage shared calendars"

, "Create new shared calendars"
: "Create new shared calendars"

, "manage shared calendars favorites"
: "manage shared calendars favorites"

, "Create or update shared calendars favorites"
: "Create or update shared calendars favorites"

, "manage resources"
: "manage resources"

, "All Rights to administrate resources"
: "All Rights to administrate resources"

, "private classification"
: "private classification"

, "recurring event"
: "recurring event"

, "has alarm"
: "has alarm"

, "Loading events, please wait..."
: "Loading events, please wait..."

, "Scheduling Conflict"
: "Scheduling Conflict"

, "The following attendee are busy at the requested time:"
: "The following attendee are busy at the requested time:"

, "Ignore Conflict"
: "Ignore Conflict"

, "Edit Event"
: "Edit Event"

, "Cancel this action"
: "Cancel this action"

, "Update Event"
: "Update Event"

, "Update this event only"
: "Update this event only"

, "Update this and all future events"
: "Update this and all future events"

, "Update whole series"
: "Update whole series"

, "Update nothing"
: "Update nothing"

, "New Event"
: "New Event"

, "{0}, the {1}. of {2}"
: "{0}, the {1}. of {2}"

, "Week"
: "Week"

, "Name"
: "Name"

, "Email"
: "Email"

, "Location"
: "Location"

, "Print Page"
: "Print Page"

, "Day"
: "Day"

, "Month"
: "Month"

, "Set my response"
: "Set my response"

, "Please Change Selection"
: "Please Change Selection"

, "Your selection contains recurring events. Recuring events must be deleted seperatly!"
: "Your selection contains recurring events. Recuring events must be deleted seperatly!"

, "Delete Event"
: "Delete Event"

, "Delete this event only"
: "Delete this event only"

, "Delete this and all future events"
: "Delete this and all future events"

, "Delete whole series"
: "Delete whole series"

, "Delete nothing"
: "Delete nothing"

, "Do you really want to delete this event?, Do you really want to delete the {0} selected events?"
: [
  "Do you really want to delete this event?"
 ,"Do you really want to delete the {0} selected events?"

]
, "Could not Print"
: "Could not Print"

, "Sorry, your current view does not support printing."
: "Sorry, your current view does not support printing."

, "Calendar, Calendars"
: [
  "Calendar"
 ,"Calendars"

]
, "Attendee Status"
: "Attendee Status"

, "Is a location"
: "Is a location"

, "Description"
: "Description"

, "Enter description..."
: "Enter description..."

, "Originally"
: "Originally"

, "WK"
: "WK"

, "{0} more..."
: "{0} more..."

, "Unknown calendar"
: "Unknown calendar"

, "{0} {1} o'clock"
: "{0} {1} o'clock"

, "Summary"
: "Summary"

, "Start Time"
: "Start Time"

, "End Time"
: "End Time"

, "Blocking"
: "Blocking"

, "Organizer"
: "Organizer"

, "Attendee"
: "Attendee"

, "Week {0} :"
: "Week {0} :"

, "whole day"
: "whole day"

, "Event, Events"
: [
  "Event"
 ,"Events"

]
, "Events"
: "Events"

, "Calendars"
: "Calendars"

, "Quick search"
: "Quick search"

, "Attender, Attendee"
: [
  "Attender"
 ,"Attendee"

]
, "No Information"
: "No Information"

, "No response"
: "No response"

, "Accepted"
: "Accepted"

, "Declined"
: "Declined"

, "Tentative"
: "Tentative"

, "Resource, Resources"
: [
  "Resource"
 ,"Resources"

]
, "Resources"
: "Resources"

, "Manage Resources"
: "Manage Resources"

, "Select Attendee"
: "Select Attendee"

, "Recurrances"
: "Recurrances"

, "No recurring rule defined"
: "No recurring rule defined"

, "None"
: "None"

, "Daily"
: "Daily"

, "Weekly"
: "Weekly"

, "Monthly"
: "Monthly"

, "Yearly"
: "Yearly"

, "Exceptions of reccuring events can't have recurrences themselves."
: "Exceptions of reccuring events can't have recurrences themselves."

, "forever"
: "forever"

, "Forever"
: "Forever"

, "at"
: "at"

, "Until"
: "Until"

, "Until has to be after event start"
: "Until has to be after event start"

, "Every {0}. Day"
: "Every {0}. Day"

, "Every {0}. Week at"
: "Every {0}. Week at"

, "Every {0}. Month"
: "Every {0}. Month"

, "at the"
: "at the"

, "first"
: "first"

, "second"
: "second"

, "third"
: "third"

, "fourth"
: "fourth"

, "last"
: "last"

, "Every {0}. Year"
: "Every {0}. Year"

, "of"
: "of"

, "Mini Calendar"
: "Mini Calendar"

, "non-blocking"
: "non-blocking"

, "Private"
: "Private"

, "Enter description"
: "Enter description"

, "End date is not valid"
: "End date is not valid"

, "End date must be after start date"
: "End date must be after start date"

, "Start date is not valid"
: "Start date is not valid"

, "Role"
: "Role"

, "Quantity"
: "Quantity"

, "This is the calendar where the attender has saved this event in"
: "This is the calendar where the attender has saved this event in"

, "Type"
: "Type"

, "User"
: "User"

, "Group"
: "Group"

, "Member of group"
: "Member of group"

, "Status"
: "Status"

, "Remove Attender"
: "Remove Attender"

, "Click here to invite another attender..."
: "Click here to invite another attender..."

, "(as a group member)"
: "(as a group member)"

, "Required"
: "Required"

, "Optional"
: "Optional"

, "Updates"
: "Updates"

, "%1$s changed from \"%2$s\" to \"%3$s\""
: "%1$s changed from \"%2$s\" to \"%3$s\""

, "%1$s has been invited"
: "%1$s has been invited"

, "%1$s has been removed"
: "%1$s has been removed"

, "%1$s accepted invitation"
: "%1$s accepted invitation"

, "%1$s declined invitation"
: "%1$s declined invitation"

, "Tentative response from %1$s"
: "Tentative response from %1$s"

, "No response from %1$s"
: "No response from %1$s"

, "Event details"
: "Event details"

, "All events I attend"
: "All events I attend"

, "Awaiting response"
: "Awaiting response"

, "Events I have not yet responded to"
: "Events I have not yet responded to"

, "Declined events"
: "Declined events"

, "Events I have declined"
: "Events I have declined"

, "I'm organizer"
: "I'm organizer"

, "Events I'm the organizer of"
: "Events I'm the organizer of"

, "%s's personal calendar"
: "%s's personal calendar"

, "Start"
: "Start"

, "End"
: "End"

, "Classification"
: "Classification"

, "Priority"
: "Priority"

, "Url"
: "Url"

, "Recurrance rule"
: "Recurrance rule"

, "Is all day event"
: "Is all day event"

, "Organizer timezone"
: "Organizer timezone"

, "Yes"
: "Yes"

, "No"
: "No"

, "unknown"
: "unknown"

, "This contact has been automatically added by the system as an event attender"
: "This contact has been automatically added by the system as an event attender"

, "unknown)"
: "unknown)"

, "All my events"
: "All my events"

, "Position on the left time axis, day and week view should start with"
: "Position on the left time axis, day and week view should start with"

, "Default Calendar"
: "Default Calendar"

, "The default calendar for invitations and new events"
: "The default calendar for invitations and new events"

, "Default Favorite"
: "Default Favorite"

, "The default favorite which is loaded on calendar startup"
: "The default favorite which is loaded on calendar startup"

, "Get Notification Emails"
: "Get Notification Emails"

, "The level of actions you want to be notified about. Please note that organizers will get notifications for all updates including attendee answers unless this preference is set to \"Never\""
: "The level of actions you want to be notified about. Please note that organizers will get notifications for all updates including attendee answers unless this preference is set to \"Never\""

, "Send Notifications Emails of own Actions"
: "Send Notifications Emails of own Actions"

, "Get notifications emails for actions you did yourself"
: "Get notifications emails for actions you did yourself"

, "Never"
: "Never"

, "On invitation and cancellation only"
: "On invitation and cancellation only"

, "On time changes"
: "On time changes"

, "On all updates but attendee responses"
: "On all updates but attendee responses"

, "On attendee responses too"
: "On attendee responses too"

})); 
